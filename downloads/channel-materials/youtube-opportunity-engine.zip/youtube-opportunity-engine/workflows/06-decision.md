# Workflow 06 — Decisão

## Opções

### EXECUTAR
Há evidência suficiente para um teste.

### AJUSTAR
O mecanismo parece forte, mas a manifestação precisa mudar.

### NOVA HIPÓTESE
A demanda continua interessante, mas a hipótese não convence.

### DESCARTAR
Evidências tornam o teste pouco promissor.

## Não use média cega

Pontuações ajudam a ordenar, não substituem julgamento.

## Para cada hipótese finalista

Informe:
- decisão
- evidência mais forte
- evidência contrária mais forte
- risco principal
- incerteza principal
- confiança
- custo do teste
- aprendizado esperado

## Loop

Se AJUSTAR:
- retorne ao H###
- crie H###-B
- preserve linhagem
- valide novamente

Se NOVA HIPÓTESE:
- retorne ao M###
- use outra família da matriz

Se DESCARTAR:
- registre por que
- não recicle a mesma ideia com palavras diferentes
