# Workflow 07 — Preparar primeiro teste

Leia:
- `frameworks/curiosity-and-package.md`

## Objetivo

Transformar a hipótese aprovada em um teste, sem ainda exigir roteiro completo.

## Defina

- tópico central
- tema
- tese
- posicionamento
- crença atacada/defendida
- mecanismo
- expectativa
- gap
- identificação
- quebra
- emoção
- promessa

## Gere 3 conceitos

Todos devem:
- testar o mesmo mecanismo
- variar a manifestação
- ser comparáveis
- evitar mudar todas as variáveis ao mesmo tempo

## Escolha 1

Explique:
- por que começar por ele
- qual variável principal está sendo testada
- o que confirmaria a hipótese
- o que a enfraqueceria
- qual informação o teste deve gerar

## Pare

Não escreva roteiro completo, salvo pedido explícito.
