# Workflow 02 — Organizar sinais

## Objetivo

Separar casos interessantes de ruído.

## Para cada item

Crie S### e registre:
- canal
- vídeo
- tópico provável
- tema provável
- formato
- métricas conhecidas
- idade do conteúdo
- baseline conhecido
- razão de ser sinal
- observações

## Tipos de sinal

- outlier dentro do canal
- aceleração recente
- padrão repetido
- formato emergente
- abordagem incomum
- demanda persistente
- reativação de formato antigo
- assimetria entre canais

## Não faça ainda

- não gere novos nichos
- não conclua mecanismo definitivo
- não diga que a brecha está validada

## Priorização

Escolha sinais que ofereçam:
- evidência clara de interesse
- contraste útil
- variedade
- possibilidade de comparação
- potencial de mecanismo transferível

Saída:
- sinais organizados
- 3 a 7 sinais prioritários
