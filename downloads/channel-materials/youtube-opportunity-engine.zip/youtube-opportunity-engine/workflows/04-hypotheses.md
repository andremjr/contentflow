# Workflow 04 — Gerar hipóteses

Leia:
- `frameworks/transfer-matrix.md`
- `frameworks/quality-gates.md`

## Fase A — Divergência

Para cada mecanismo forte, gere de 15 a 30 transposições.

Distribua entre várias famílias:
- mesma demanda, nova execução
- mesmo tópico, novo tema
- mesma crença, outra posição
- mesmo público, demanda adjacente
- mesmo mecanismo, outro tópico
- mesmo tópico, outro público
- mesmo formato, outra demanda
- outro ponto de vista
- outra estrutura narrativa
- outra escala
- combinação de mecanismos

Não aplique pontuação detalhada durante a geração.

## Fase B — Deduplicação

Agrupe hipóteses que são estrategicamente iguais.

Pergunta:
"Se eu trocasse os substantivos, elas seriam o mesmo movimento?"

Se sim:
- agrupe
- mantenha a melhor formulação

## Fase C — Filtro

Aplique:
- demanda
- integridade do mecanismo
- crença
- identificação
- quebra
- emoção
- novidade
- entregabilidade
- testabilidade

Selecione 5 a 10 hipóteses.

## Para cada H###

Registre:
- mecanismo de origem
- demanda-alvo
- público
- tópico
- tema
- tese
- crença
- identificação
- quebra
- emoção
- gap provável
- diferença da oferta
- risco
- estado = `unvalidated`

## Critério especial

A hipótese precisa ser diferente por mecanismo de execução, não só por palavras.
