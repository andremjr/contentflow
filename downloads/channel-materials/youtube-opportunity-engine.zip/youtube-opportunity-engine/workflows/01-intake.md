# Workflow 01 — Intake

## Objetivo

Entender o que o usuário quer descobrir e quais evidências existem.

## Colete somente o necessário

Pergunte ou extraia:
- objetivo da análise
- mercado/nicho/tópico, se já definido
- país/idioma, se relevante
- tipo de canal ou restrições, se houver
- dados disponíveis
- fonte dos dados
- horizonte temporal
- se deseja explorar o mesmo tópico ou transpor para outros
- restrições de produção, se relevantes

## Não exija

O usuário não precisa ter:
- nicho definido
- público perfeitamente definido
- hipótese pronta

## Saída

Crie:
- `case_id`
- objetivo
- restrições
- fontes
- itens de evidência recebidos
- lacunas

## Se faltarem dados

Peça um lote de sinais.

Sugestão:
- 5 a 20 vídeos/canais
- títulos
- views
- idade do vídeo
- baseline do canal, quando disponível

Não bloqueie por ausência de todas as métricas.
