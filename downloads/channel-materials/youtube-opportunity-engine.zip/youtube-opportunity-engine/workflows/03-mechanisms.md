# Workflow 03 — Extrair mecanismos

Leia:
- `frameworks/belief-system.md`
- `frameworks/mechanism-extraction.md`

## Para cada sinal prioritário

Analise:

### Público
- quem
- desejo
- medo
- problema
- estágio

### Sistema de crenças
- crença ativada
- crença defendida/atacada
- expectativa
- autoridade percebida
- objeção

### Identificação
Por que "isso é para mim"?

### Quebra
O que foge do esperado?

### Emoção
O que a quebra provoca?

### Gap
- expectativa
- informação faltante

### Superfície
Liste os elementos removíveis.

### Mecanismo
Resuma em uma frase abstrata.

## Gere M###

Cada mecanismo deve conter:
- sinais de origem
- descrição
- crença-base
- emoção
- elementos necessários
- elementos acidentais
- confiança
- explicações alternativas

## Regra anti-alucinação

Se a crença ou mecanismo não tiver evidência suficiente:
- marque como inferido
- não trate como fato
