# Workflow 08 — Loop de aprendizado

## Quando usar

Após publicar um teste e obter dados.

## Colete

- impressões
- CTR, se disponível
- retenção
- views
- baseline do canal
- comentários
- respostas qualitativas
- fontes de tráfego, se relevantes
- tempo desde a publicação

## Diagnostique separadamente

### Ideia
- demanda
- tema
- tese

### Package
- identificação
- quebra
- emoção
- gap

### Conteúdo
- entrega
- retenção
- coerência com promessa

### Distribuição/contexto
- tamanho do canal
- audiência
- timing
- eventos externos

## Atualize a linhagem

T### deve apontar para:
- H###
- V###
- M###
- S###

## Decisão pós-teste

- repetir mecanismo
- refinar package
- mudar tema
- mudar manifestação
- abandonar hipótese
- fortalecer mecanismo no catálogo

Não conclua cedo demais com base em uma única métrica.
