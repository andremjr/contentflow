# Workflow 05 — Validar hipóteses

Leia:
- `frameworks/evidence-and-confidence.md`
- `frameworks/quality-gates.md`

## Antes da pesquisa

Para cada hipótese gere consultas em camadas:

### Exata
- formulação direta

### Semântica
- sinônimos
- reescritas
- termos equivalentes

### Mecanismo
- pesquise a lógica sem a superfície

### Demanda
- problema/desejo + abordagem

### Formato
- formato + demanda

### Crença
- crença + oposição/defesa

### Temporal
- recente
- histórico
- quando fizer sentido

Use `scripts/build_search_queries.py` se disponível.
Caso contrário, faça manualmente.

## Cenários

### A — Ninguém parece ter feito

Não validar automaticamente.

Investigue:
- busca insuficiente?
- linguagem diferente?
- sem demanda?
- brecha real?
- ideia incoerente?

### B — Fizeram e funcionou

Investigue:
- valida o mecanismo?
- valida o tema?
- foi outlier?
- repetiu?
- ainda há diferenciação?

### C — Fizeram e foi fraco

Diagnostique:

#### Execução
- package
- formato
- promessa
- canal
- contexto
- retenção
- clareza

#### Mecanismo
- crença errada
- demanda fraca
- quebra irrelevante
- emoção fraca
- identificação baixa

Pergunta obrigatória:
"Mecanismo ou execução?"

## Saída V###

- hipótese
- consultas usadas
- resultados relevantes
- positivos
- negativos
- ausências
- cenário A/B/C
- interpretação
- confiança
- próximo passo
