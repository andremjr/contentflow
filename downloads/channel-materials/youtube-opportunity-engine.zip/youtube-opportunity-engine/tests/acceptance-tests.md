# Testes de aceitação

A skill só é considerada robusta se passar conceitualmente por estes testes.

## Teste 1 — Não copiar superfície

Entrada:
- um vídeo viral com personagem, objeto e frase marcante

Esperado:
- separar elementos removíveis do mecanismo
- não gerar apenas substituições lexicais

Falha:
- ideias são o mesmo título com substantivos trocados

## Teste 2 — Mesmo tópico, temas diferentes

Entrada:
- um tópico com demanda comprovada

Esperado:
- gerar teses de defesa, ataque, tensão e reorganização

Falha:
- tratar tópico como se fosse tema

## Teste 3 — Outro tópico

Entrada:
- mecanismo abstrato forte

Esperado:
- transportar para outra demanda com crença coerente

Falha:
- escolher novo nicho sem justificar identificação

## Teste 4 — Canal narrativo

Entrada:
- histórias/relatos

Esperado:
- extrair mecanismos narrativos, não só "curiosidade"

## Teste 5 — Canal educativo

Entrada:
- conteúdo didático

Esperado:
- considerar autoridade, transformação, clareza e crença

## Teste 6 — Entretenimento

Entrada:
- desafio, humor ou competição

Esperado:
- extrair conflito, risco, status, surpresa ou identificação

## Teste 7 — Evidência contrária

Entrada:
- hipótese com exemplos fracos

Esperado:
- investigar execução x mecanismo
- não defender a ideia por apego

## Teste 8 — Nenhum resultado

Entrada:
- busca sem correspondência

Esperado:
- classificar como evidência insuficiente ou brecha possível
- nunca como oportunidade confirmada

## Teste 9 — Sem Python

Ambiente:
- nenhum runtime local

Esperado:
- fluxo completo via Markdown

Falha:
- skill pede instalação

## Teste 10 — Dados incompletos

Entrada:
- apenas títulos + views

Esperado:
- trabalhar com confiança menor
- pedir dados adicionais apenas se críticos

## Teste 11 — Claims frágeis

Entrada:
- ideia atraente baseada em afirmação não sustentada

Esperado:
- separar potencial de clique de validade factual
- reformular ou rejeitar

## Teste 12 — Linhagem

Entrada:
- hipótese refinada três vezes

Esperado:
- manter S → M → H → V → refinamento → teste
