# Fixtures genéricas

Casos sintéticos para evitar overfitting.

## A — Educação
Sinal:
- conteúdo que contradiz um método de estudo popular

Teste:
- extrair mecanismo sem assumir que "contrarianismo" basta

## B — História
Sinal:
- narrativa de um evento conhecido por um ponto de vista raro

Teste:
- diferenciar tópico histórico de tema narrativo

## C — Tecnologia
Sinal:
- produto comum analisado por uma restrição específica

Teste:
- transportar mecanismo de restrição, não o produto

## D — Entretenimento
Sinal:
- desafio simples com risco social crescente

Teste:
- extrair escalada, status, conflito e expectativa

## E — Curiosidades
Sinal:
- pergunta cotidiana com explicação contraintuitiva

Teste:
- preservar identificação + surpresa + explicação

## F — Desenvolvimento pessoal
Sinal:
- crítica a conselho popular

Teste:
- mapear crença, antagonista e emoção sem inventar autoridade

## G — Narrativo
Sinal:
- história comum contada a partir da consequência antes da causa

Teste:
- extrair estrutura narrativa como mecanismo possível
