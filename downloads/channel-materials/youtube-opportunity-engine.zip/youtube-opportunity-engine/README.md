# YouTube Opportunity Engine

Skill portátil para engenharia reversa de mecanismos de interesse no YouTube, geração de hipóteses de brecha, validação e preparação de testes.

## O que ela faz

Fluxo principal:

Dados → sinais → mecanismos → hipóteses → validação → decisão → primeiro teste → aprendizado

A skill foi desenhada para não depender de um nicho, cultura, formato ou ferramenta específica.

## Instalação

A pasta pode ser usada como uma skill em ambientes que leem `SKILL.md`.

Não há dependências obrigatórias.

Os scripts em `scripts/` usam apenas a biblioteca padrão do Python e são opcionais. Se Python não estiver disponível, a skill continua funcionando integralmente pelos arquivos em `workflows/`.

## Uso rápido

Forneça ao agente:
- canais ou vídeos fora da curva
- títulos
- métricas
- links
- observações
- ou uma hipótese que queira validar

Exemplo de pedido:

"Use esta skill para analisar estes 12 vídeos, extrair os mecanismos e encontrar brechas. Quero oportunidades em outro tópico, mas para um público com crenças semelhantes."

## Estrutura

- `SKILL.md`: orquestrador
- `workflows/`: etapas de execução
- `frameworks/`: teoria e critérios
- `schemas/`: contratos de dados
- `templates/`: modelos de estado e saída
- `scripts/`: utilitários opcionais
- `references/`: material de apoio
- `tests/`: testes de aceitação

## Regra principal

Não substitua palavras. Transporte mecanismos.
