# Prompts manuais equivalentes

Use quando a skill não puder ser instalada e o usuário quiser executar o método em uma conversa comum.

## Prompt A — Sinais e mecanismo

Quero analisar estes canais e vídeos como sinais, não como modelos para copiar.

Para cada exemplo:
- identifique nicho, público, tópico, tema e formato
- diga o que está fora da curva
- mapeie crenças, identificação, quebra de padrão e emoção
- separe superfície de mecanismo
- proponha explicações alternativas
- dê um nível de confiança

Não gere oportunidades ainda.

Dados:
[COLE AQUI]

## Prompt B — Transposição e hipóteses

Com base nos mecanismos extraídos, abra o espaço criativo antes de filtrar.

Gere 15 a 30 aplicações possíveis variando várias dimensões:
- mesmo tópico, novo tema
- mesma demanda, novo formato
- mesma crença, outra posição
- mesmo público, demanda adjacente
- mesmo mecanismo, outro tópico
- mesmo tópico, outro público
- outro ponto de vista
- outra estrutura
- outra escala
- combinação de mecanismos

Não faça simples trocas de palavras.

Depois deduplique e selecione 5 a 10 hipóteses com melhor equilíbrio entre:
- demanda
- crença
- identificação
- quebra
- emoção
- novidade
- integridade do mecanismo
- testabilidade

## Prompt C — Validação e decisão

Agora vou trazer resultados de pesquisa para validar as hipóteses.

Para cada uma, compare:
- ninguém fez
- fizeram e funcionou
- fizeram e foi fraco

Não confunda ausência de evidência com validação.

Quando houver fracasso, separe:
- falha de execução
- falha de mecanismo

Classifique:
- EXECUTAR
- AJUSTAR
- NOVA HIPÓTESE
- DESCARTAR

Para cada decisão:
- evidência mais forte
- evidência contrária
- risco
- incerteza
- teste mínimo recomendado
