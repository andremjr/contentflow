# Adaptadores de fonte

A metodologia não depende de uma ferramenta específica.

## Radar ou ferramenta de descoberta

Use quando o usuário fornecer exportação, prints, títulos ou métricas.

Objetivo:
- transformar saída bruta em sinais

Não assuma que o ranking da ferramenta já representa oportunidade.

## Pesquisa manual no YouTube

Peça:
- consulta
- títulos
- canais
- views
- idade
- inscritos, quando visível
- observações

## Navegador/web disponível

Pesquise diretamente quando permitido.

Regras:
- documentar consultas
- buscar variações
- buscar evidência contrária
- distinguir dados atuais de inferência

## Links fornecidos

Leia o conteúdo acessível.
Se não puder acessar:
- peça títulos/métricas
- não invente

## CSV/tabela

Normalize colunas:
- title
- channel
- views
- published_at
- subscribers
- duration
- url
- notes

Campos ausentes são permitidos.
