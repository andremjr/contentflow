# Claims e segurança de promessas

O potencial de clique não transforma uma afirmação em verdade.

Separe:
- força estratégica
- validade factual

Em saúde, finanças, segurança e outros temas de maior risco:
- evite garantias
- evite causalidade não demonstrada
- evite prazos arbitrários
- evite "especialistas escondem" sem evidência
- evite alegações fabricadas

Se a ideia depende de uma alegação fraca:
- preserve o mecanismo
- reformule a promessa
- reduza a certeza
- mantenha a curiosidade sem inventar fatos
