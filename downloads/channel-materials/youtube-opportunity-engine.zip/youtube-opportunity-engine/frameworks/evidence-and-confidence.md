# Evidência e confiança

## Classes

### Fato observado
Dado fornecido ou verificado.

Exemplo:
"O vídeo tem X visualizações."

### Inferência
Interpretação plausível.

Exemplo:
"O contraste pode ter contribuído para o clique."

### Hipótese
Explicação a ser testada.

Exemplo:
"O mecanismo pode ser transferível para outra demanda."

### Decisão
Escolha operacional baseada no conjunto de evidências.

## Evidência mínima

Prefira:
- vários casos
- comparação com baseline do canal
- repetição em canais diferentes
- sinais recentes e históricos
- dados de demanda
- evidência contrária

## Outlier

Não trate um único viral como regra.

Pergunte:
- o canal costuma ter esse desempenho?
- houve repetição?
- existe outro caso?
- o título/thumbnail eram excepcionais?
- houve evento externo?
- há viés de sobrevivência?

## Ausência de resultado

"Não encontrei" pode significar:
- brecha
- busca ruim
- vocabulário diferente
- demanda inexistente
- plataforma não indexou
- ideia nova demais
- execução anterior invisível

Nunca chame ausência de evidência de validação.

## Confiança

Use:
- alta
- média
- baixa

Sempre explique por quê.
