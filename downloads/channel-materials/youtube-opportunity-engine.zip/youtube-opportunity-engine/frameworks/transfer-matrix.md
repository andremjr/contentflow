# Matriz de transposição

## Objetivo

Explorar o máximo de espaço criativo sem perder coerência.

Não existe uma dimensão obrigatória de variação.

## Família A — Mesma demanda, nova execução

Varie:
- tema
- tese
- posicionamento
- formato
- estrutura
- ponto de vista
- antagonista
- promessa
- linguagem
- nível de especificidade
- duração
- ritmo

## Família B — Mesmo público, demanda adjacente

Varie:
- problema
- desejo
- medo
- ambição
- situação
- estágio da jornada
- contexto de uso

## Família C — Mesmo mecanismo, outro tópico

Transporte a lógica abstrata.

Verifique:
- crença equivalente
- identificação
- emoção
- autoridade percebida
- relevância
- demanda existente

## Família D — Mesmo tópico, outro público

Varie:
- iniciante / avançado
- idade ou fase de vida, quando relevante
- profissão
- objetivo
- contexto
- motivação
- restrição
- consciência do problema

Não use atributos pessoais sensíveis como atalho de segmentação.

## Família E — Mesma crença, posição diferente

- defender
- atacar
- tensionar
- inverter
- contextualizar
- mostrar exceção
- mostrar limite
- mostrar consequência

## Família F — Mesmo formato, outra demanda

Pergunte:
"Que outro público reconheceria valor neste formato?"

## Família G — Mecanismo composto

Combine dois mecanismos quando:
- ambos são claros
- a combinação aumenta valor
- não cria confusão
- a promessa continua simples

## Família H — Temporalidade

Varie:
- novo x antigo
- antes x depois
- agora x futuro
- atualização
- retorno de formato
- ciclo recorrente

## Família I — Escala

Varie:
- micro
- macro
- extremo
- mínimo viável
- primeiro passo
- sistema completo

## Teste da boa transposição

Uma boa hipótese tende a gerar:

"Nunca tinha pensado nisso, mas faz sentido."

Muito distante:
- exige longa defesa
- identificação baixa

Muito óbvia:
- provavelmente já está ocupada

Procure o meio:
- familiar
- diferente
- emocionalmente relevante
