# Extração de mecanismo

## Objetivo

Retirar elementos superficiais até restar uma explicação transferível.

## Escada de abstração

Para cada caso:

### Camada 1 — O que aconteceu?
Descreva o vídeo sem interpretar.

### Camada 2 — O que prometeu?
Qual resultado, descoberta ou experiência?

### Camada 3 — Por que isso importa?
Qual desejo, medo, problema ou identidade?

### Camada 4 — Qual expectativa existia?
O que o público normalmente esperaria?

### Camada 5 — O que rompeu essa expectativa?
Onde está a quebra?

### Camada 6 — Qual emoção surgiu?
Por que a quebra tem peso?

### Camada 7 — Qual crença tornou isso plausível?
Sem essa crença, a proposta ainda funcionaria?

### Camada 8 — O que sobra se removermos nomes e nicho?
Esse é o candidato a mecanismo.

## Teste de remoção

Remova:
- nomes próprios
- nacionalidade
- produto
- personagem
- nicho
- palavras exatas do título

Pergunte:
"A lógica continua compreensível?"

Se não, você provavelmente ainda está descrevendo superfície.

## Múltiplos mecanismos

Um conteúdo pode combinar:
- mecanismo primário
- mecanismo secundário
- amplificador

Não force um único mecanismo quando a evidência aponta combinação.

## Nível de confiança

### Alto
Vários sinais independentes sustentam a mesma explicação.

### Médio
A explicação encaixa bem, mas existem alternativas plausíveis.

### Baixo
Baseada em poucos dados ou inferência especulativa.
