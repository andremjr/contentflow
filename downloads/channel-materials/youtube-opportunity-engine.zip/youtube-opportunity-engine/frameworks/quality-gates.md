# Quality gates

Uma hipótese não avança automaticamente.

## Gate 1 — Demanda

Perguntas:
- há interesse observável?
- existe recorrência?
- o público tem motivo para consumir?

Falha:
- interesse puramente imaginado

## Gate 2 — Integridade do mecanismo

Perguntas:
- o mecanismo foi realmente preservado?
- ou apenas a superfície mudou?

Falha:
- troca lexical

## Gate 3 — Sistema de crenças

Perguntas:
- a hipótese encaixa em crenças reais?
- a quebra faz sentido nesse contexto?

Falha:
- depende de crença inventada

## Gate 4 — Identificação

Pergunta:
- o público reconhece relevância rapidamente?

Falha:
- precisa de longa explicação para importar

## Gate 5 — Quebra

Pergunta:
- existe diferença real da oferta?

Falha:
- mais do mesmo

## Gate 6 — Emoção

Pergunta:
- a diferença provoca reação?

Falha:
- estranho, mas indiferente

## Gate 7 — Validação

Perguntas:
- pesquisamos a hipótese?
- buscamos sinônimos?
- procuramos evidência contrária?

Falha:
- conclusão baseada em memória

## Gate 8 — Entregabilidade

Perguntas:
- a promessa pode ser cumprida?
- há risco de afirmação enganosa?

Falha:
- clique depende de alegação não sustentada

## Gate 9 — Testabilidade

Pergunta:
- existe um teste simples que ensine algo?

Falha:
- exige grande investimento antes de gerar informação

## Resultado

Uma hipótese pode:
- passar
- passar com ressalvas
- voltar para refinamento
- ser descartada
