# Curiosidade e package

## Gap

Curiosidade não é esconder tudo.

Gap forte:

EXPECTATIVA + INFORMAÇÃO FALTANTE

O público precisa entender:
- sobre o que é
- por que importa
- o que pode ganhar
- o que ainda não sabe

## Tríade do package

IDENTIFICAÇÃO + QUEBRA DE PADRÃO + EMOÇÃO

### Identificação
"Isso é para mim."

### Quebra
"Isso não é o que eu esperava."

### Emoção
"Eu preciso resolver/ver/entender isso."

## Título e thumbnail

Devem cooperar.

Evite:
- repetir a mesma informação
- vaguidão total
- exagero impossível
- promessa que o conteúdo não sustenta
- diferença só estética

## Tema não é package

Primeiro:
- tópico
- tema
- tese
- crença
- mecanismo

Depois:
- expectativa
- gap
- package
