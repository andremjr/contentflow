# Ontologia operacional

## Sinal
Caso que merece investigação:
- vídeo fora da curva
- canal em aceleração
- padrão recorrente
- formato reaparecendo
- diferença anormal de desempenho

Um sinal não é uma oportunidade.

## Demanda
Interesse humano recorrente:
- problema
- desejo
- medo
- identidade
- ambição
- curiosidade
- necessidade
- entretenimento

## Tópico central
Caixa de demanda na qual o conteúdo se encaixa.

Exemplos genéricos:
- crescimento profissional
- relacionamentos
- história
- tecnologia
- bem-estar

## Tema
Tese ou posicionamento específico sobre o tópico.

Pergunta:
"O que este conteúdo está dizendo sobre esse tópico?"

## Superfície
Elementos observáveis:
- personagem
- cenário
- nicho
- objeto
- estrutura visível
- palavras do título
- estética
- duração

## Mecanismo
Lógica abstrata que pode explicar o interesse.

Pode envolver:
- crença
- expectativa
- contraste
- autoridade percebida
- risco
- recompensa
- novidade
- conflito
- identidade
- prova
- status
- transformação
- reversão
- descoberta

## Sistema de crenças
Mapa de pressupostos do público:
- acredita
- deseja
- teme
- rejeita
- considera óbvio
- considera controverso
- reconhece como autoridade
- está cansado de ouvir

## Identificação
Razão pela qual o público reconhece:
"isso é para mim".

## Quebra de padrão
Diferença relevante em relação à expectativa.

## Emoção
Reação provocada pela diferença:
- curiosidade
- medo
- desejo
- esperança
- surpresa
- indignação
- ambição
- nostalgia
- alívio
- pertencimento

## Gap de curiosidade
Expectativa concreta + informação relevante faltante.

## Hipótese
Nova aplicação proposta de um mecanismo.

## Brecha
Hipótese com evidência suficiente para justificar teste e diferenciação suficiente em relação à oferta atual.

## Validação
Busca deliberada de evidência favorável e contrária.

## Teste
Execução mínima capaz de gerar nova informação do público.
