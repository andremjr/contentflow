# Sistema de crenças do público

## Objetivo

Entender o terreno mental em que o conteúdo será recebido.

## Mapear

Pergunte:

- O que o público acredita ser verdade?
- O que ele deseja que seja verdade?
- O que teme que seja verdade?
- O que rejeita imediatamente?
- O que considera solução legítima?
- O que considera perda de tempo?
- Quais autoridades reconhece?
- Quais explicações parecem intuitivas?
- Quais opiniões dividem o grupo?
- Quais histórias o público conta para explicar seus resultados?
- Quais experiências anteriores moldam sua reação?
- Em que estágio de consciência está?

## Posicionamentos possíveis

### Defesa
Reforça uma crença existente.

### Ataque
Contradiz uma crença existente.

### Tensão
Aceita parte da crença, mas mostra uma exceção.

### Reorganização
Mostra que a crença explica o fenômeno errado.

## Regra

Não invente crenças porque seriam convenientes para a hipótese.

Procure evidência em:
- títulos recorrentes
- comentários
- perguntas
- vídeos com desempenho
- linguagem repetida
- objeções
- comunidades
- resultados de busca

Marque crenças como:
- observada
- inferida
- não confirmada
