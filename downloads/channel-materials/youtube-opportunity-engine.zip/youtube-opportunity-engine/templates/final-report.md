# Relatório de oportunidade

## Oportunidade escolhida
- Hipótese:
- Público:
- Demanda:
- Tópico:
- Tema:
- Mecanismo:
- Crença:
- Identificação:
- Quebra:
- Emoção:
- Gap:
- Diferenciação:

## Linhagem
S### → M### → H### → V### → T###

## Evidências
### Favoráveis
-

### Contrárias
-

### Ausentes
-

## Decisão
-

## Confiança
-

## Risco principal
-

## Primeiro teste
- conceito:
- variável:
- confirmação:
- enfraquecimento:
