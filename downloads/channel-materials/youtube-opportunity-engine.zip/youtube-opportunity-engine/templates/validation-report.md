# V### — Validação

## Hipótese
H###

## Consultas
-

## Evidência favorável
-

## Evidência contrária
-

## Ausências relevantes
-

## Cenário
A / B / C / MIXED

## Diagnóstico
- mecanismo:
- execução:
- incertezas:

## Confiança
baixa / média / alta

## Próximo passo
EXECUTAR / AJUSTAR / NOVA HIPÓTESE / DESCARTAR
