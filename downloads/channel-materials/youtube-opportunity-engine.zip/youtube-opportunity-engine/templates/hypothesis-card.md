# H### — Hipótese

## Origem
- Mecanismo:
- Sinais:

## Aplicação
- Demanda:
- Público:
- Tópico:
- Tema:
- Tese:

## Psicologia
- Crença:
- Identificação:
- Quebra:
- Emoção:
- Gap:

## Diferenciação
- O que muda:
- O que permanece:
- Por que não é só troca superficial:

## Risco
-

## Estado
unvalidated
