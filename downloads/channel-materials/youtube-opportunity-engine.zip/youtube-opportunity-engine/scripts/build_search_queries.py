#!/usr/bin/env python3
"""
Opcional. Usa somente a biblioteca padrão.
Gera variações de busca a partir de uma hipótese.
Não acessa a internet.
"""
import argparse

def queries(topic, theme, belief="", mechanism="", format_hint=""):
    raw = [
        f'"{theme}"',
        f'{topic} {theme}',
        f'{topic} {belief}' if belief else '',
        f'{topic} {mechanism}' if mechanism else '',
        f'{format_hint} {topic}' if format_hint else '',
        f'{belief} {theme}' if belief else '',
        f'{mechanism} {theme}' if mechanism else '',
    ]
    out = []
    seen = set()
    for q in raw:
        q = " ".join(q.split()).strip()
        if q and q.lower() not in seen:
            seen.add(q.lower())
            out.append(q)
    return out

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--topic", required=True)
    p.add_argument("--theme", required=True)
    p.add_argument("--belief", default="")
    p.add_argument("--mechanism", default="")
    p.add_argument("--format", default="")
    a = p.parse_args()
    for q in queries(a.topic, a.theme, a.belief, a.mechanism, a.format):
        print(q)
