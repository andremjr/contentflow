#!/usr/bin/env python3
"""
Opcional. Validação leve sem dependências externas.
Não implementa JSON Schema completo; verifica o contrato mínimo da skill.
"""
import argparse, json, sys, re

REQ = ["case_id", "objective", "signals", "mechanisms", "hypotheses", "validations", "tests"]

def fail(msg):
    print("ERRO:", msg)
    return 1

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("file")
    a = p.parse_args()
    try:
        data = json.load(open(a.file, encoding="utf-8"))
    except Exception as e:
        sys.exit(fail(f"JSON inválido: {e}"))
    errors = 0
    for k in REQ:
        if k not in data:
            errors += fail(f"campo ausente: {k}")
    for k in ["signals", "mechanisms", "hypotheses", "validations", "tests"]:
        if k in data and not isinstance(data[k], list):
            errors += fail(f"{k} deve ser lista")
    ids = []
    for section in ["signals", "mechanisms", "hypotheses", "validations", "tests"]:
        for obj in data.get(section, []):
            if "id" in obj:
                ids.append(obj["id"])
    if len(ids) != len(set(ids)):
        errors += fail("IDs duplicados")
    if errors:
        sys.exit(1)
    print("OK: case_state mínimo válido")
