#!/usr/bin/env python3
"""
Opcional. Deduplicação lexical simples para triagem.
Não substitui o julgamento estratégico do agente.
Entrada: JSON com lista de objetos contendo id, topic, theme, thesis.
"""
import argparse, json, re
from difflib import SequenceMatcher

def norm(s):
    s = (s or "").lower()
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    return " ".join(s.split())

def fingerprint(h):
    return norm(" ".join([h.get("topic",""), h.get("theme",""), h.get("thesis","")]))

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("file")
    p.add_argument("--threshold", type=float, default=0.82)
    a = p.parse_args()
    data = json.load(open(a.file, encoding="utf-8"))
    groups, used = [], set()
    for i, h in enumerate(data):
        if i in used:
            continue
        g = [h.get("id", str(i))]
        used.add(i)
        fi = fingerprint(h)
        for j in range(i+1, len(data)):
            if j in used:
                continue
            score = SequenceMatcher(None, fi, fingerprint(data[j])).ratio()
            if score >= a.threshold:
                g.append(data[j].get("id", str(j)))
                used.add(j)
        groups.append(g)
    print(json.dumps(groups, ensure_ascii=False, indent=2))
