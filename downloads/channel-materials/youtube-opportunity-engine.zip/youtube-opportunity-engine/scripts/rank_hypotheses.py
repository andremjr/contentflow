#!/usr/bin/env python3
"""
Opcional. Ordena hipóteses a partir de notas já atribuídas pelo agente.
As notas NÃO são fatos e não substituem quality gates.
Entrada JSON: lista com `scores` contendo valores 0..4.
"""
import argparse, json

WEIGHTS = {
    "demand": 1.4,
    "mechanism_integrity": 1.5,
    "belief_coherence": 1.2,
    "identification": 1.2,
    "pattern_break": 1.0,
    "emotion": 1.0,
    "differentiation": 1.1,
    "validation": 1.5,
    "deliverability": 1.0,
    "testability": 0.8,
}

def score(h):
    s = h.get("scores", {})
    total = 0.0
    denom = 0.0
    for k, w in WEIGHTS.items():
        if k in s:
            total += float(s[k]) * w
            denom += 4.0 * w
    return round((total / denom * 100.0) if denom else 0.0, 1)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("file")
    a = p.parse_args()
    data = json.load(open(a.file, encoding="utf-8"))
    out = [{"id": h.get("id"), "score": score(h)} for h in data]
    out.sort(key=lambda x: x["score"], reverse=True)
    print(json.dumps(out, ensure_ascii=False, indent=2))
