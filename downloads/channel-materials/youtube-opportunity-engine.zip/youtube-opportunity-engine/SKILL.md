---
name: youtube-opportunity-engine
description: Analisa sinais de desempenho no YouTube, extrai mecanismos de interesse, gera e valida hipóteses de brecha e prepara testes. Use para estudar canais, vídeos, nichos, tópicos, formatos, abordagens ou demandas e encontrar oportunidades sem copiar superfícies ou perseguir "nichos secretos".
---

# YouTube Opportunity Engine

## Missão

Transformar evidências do YouTube em hipóteses de oportunidade testáveis.

A skill deve funcionar em diferentes:
- nichos
- tópicos
- formatos
- públicos
- idiomas
- abordagens
- modelos de canal
- canais com ou sem rosto
- vídeos longos ou curtos

Ela não deve depender de um exemplo específico, cultura, nicho ou formato usado em calibração.

## Princípios centrais

- Não procure apenas o que está funcionando; procure por que funciona.
- Não copie a superfície; extraia o mecanismo.
- Tópico é demanda. Tema é o posicionamento dentro dela.
- O público já chega com crenças, desejos, medos e expectativas.
- Identificação sem quebra pode parecer comum.
- Quebra sem identificação pode parecer irrelevante.
- Quebra sem emoção é apenas diferença.
- Curiosidade exige expectativa + informação faltante.
- Primeiro divergir; depois filtrar.
- Toda brecha começa como hipótese, não como certeza.
- Ausência de concorrência não é validação.
- Falha de execução não é automaticamente falha de mecanismo.
- Não buscamos certeza; buscamos evidência suficiente para justificar um teste.
- Toda conclusão deve preservar a linhagem: sinal → mecanismo → hipótese → validação → decisão → teste.

## Regra zero-install

A skill NÃO pode depender de Python, Node, bibliotecas externas, servidor local ou software instalado pelo usuário.

Se o ambiente permitir executar scripts, use `scripts/` apenas como aceleradores opcionais.
Se não permitir, execute a mesma lógica seguindo os workflows em Markdown.
Nunca interrompa o processo por ausência de runtime.

## Fontes de dados

Aceite:
- dados copiados de ferramentas de radar
- resultados de pesquisa no YouTube
- links de canais ou vídeos
- títulos e thumbnails
- métricas fornecidas pelo usuário
- tabelas, CSV ou texto
- pesquisa web/navegador, quando disponível

Se não houver acesso a dados atuais:
- não invente resultados
- gere consultas de pesquisa
- diga exatamente o que o usuário deve trazer
- continue com o que for possível

## Modos

### Guiado
Execute uma etapa por vez e pare quando precisar de novos dados.

### Completo
Execute todas as etapas possíveis. Pare apenas quando uma etapa exigir evidência externa ausente.

### Revisão
Receba uma hipótese pronta e comece pela validação crítica.

## Estado do caso

Mantenha um `case_state` lógico durante toda a análise.

IDs:
- S### = sinal
- M### = mecanismo
- H### = hipótese
- V### = validação
- T### = teste

Nunca perca a origem de uma hipótese.

## Roteamento

1. Leia `frameworks/ontology.md`.
2. Inicie com `workflows/01-intake.md`.
3. Organize evidências com `workflows/02-signals.md`.
4. Extraia mecanismos com `workflows/03-mechanisms.md`.
5. Gere e filtre hipóteses com `workflows/04-hypotheses.md`.
6. Valide com `workflows/05-validation.md`.
7. Decida com `workflows/06-decision.md`.
8. Prepare o primeiro teste com `workflows/07-first-test.md`.
9. Se houver resultado real do teste, use `workflows/08-learning-loop.md`.

Consulte frameworks adicionais somente quando a etapa exigir:
- `frameworks/belief-system.md`
- `frameworks/mechanism-extraction.md`
- `frameworks/transfer-matrix.md`
- `frameworks/curiosity-and-package.md`
- `frameworks/evidence-and-confidence.md`
- `frameworks/quality-gates.md`

## Regras de comportamento

### Não pule do viral para a ideia
Um caso fora da curva é evidência para investigar, não modelo para copiar.

### Não confunda correlação com causa
Um vídeo pode ter performado por vários fatores. Expresse mecanismo como hipótese com nível de confiança.

### Não fique preso ao nicho original
Depois de extrair o mecanismo, explore:
- mesma demanda, nova execução
- mesmo tópico, novo tema
- mesmo público, outra demanda
- mesmo mecanismo, outro tópico
- mesmo tópico, outro público
- outro formato
- outro ponto de vista
- outra estrutura narrativa
- outro antagonista
- outra promessa
- outra emoção
- combinação de mecanismos

### Não transforme exemplos em regras
Exemplos são calibração, nunca restrições.

### Não mate criatividade com filtros prematuros
Na fase divergente, gere amplitude.
Na fase convergente, aplique critérios fortes.

### Seja crítico
Rejeite hipóteses:
- só lexicais
- sem demanda observável
- sem elo com crenças
- sem identificação
- com quebra irrelevante
- emocionalmente fracas
- já saturadas sem diferenciação
- dependentes de promessa não sustentada

### Diferencie
- fato observado
- inferência
- hipótese
- decisão

## Saída padrão

Quando concluir o fluxo, entregue:

### Oportunidade escolhida
- hipótese
- público
- demanda
- tópico
- tema
- mecanismo
- crença
- identificação
- quebra
- emoção
- gap
- diferenciação

### Evidências
- sinais de origem
- validações positivas
- validações negativas
- lacunas de evidência

### Decisão
- EXECUTAR
- AJUSTAR
- NOVA HIPÓTESE
- DESCARTAR

### Risco principal
- descrição curta

### Primeiro teste
- conceito
- variável principal testada
- resultado que confirmaria
- resultado que enfraqueceria

## Encerramento

Nunca diga que uma oportunidade "vai funcionar".
Diga por que vale ou não vale testar.
